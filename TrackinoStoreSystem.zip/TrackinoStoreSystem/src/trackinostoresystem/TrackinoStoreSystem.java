package trackinostoresystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TrackinoStoreSystem extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    
    private CardLayout storeCardLayout;
    private JPanel storeContentPanel;
 
    private int cartCount = 0;
    private JLabel cartLabel;

    public TrackinoStoreSystem() {
        setTitle("TRACKINO STORE SYSTEM - FULL PROTOTYPE");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        JPanel loginPage = createLoginPage();
        JPanel storeMainPage = createStoreMainPage();
        
        mainPanel.add(loginPage, "Login");
        mainPanel.add(storeMainPage, "StoreMain");

        add(mainPanel);
        cardLayout.show(mainPanel, "Login");
    }

    private JPanel createLoginPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(18, 30, 49));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("TRACKINO STORE", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.LIGHT_GRAY);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(userLabel, gbc);

        JTextField userField = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(userField, gbc);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.LIGHT_GRAY);
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(passLabel, gbc);

        JPasswordField passField = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(passField, gbc);

        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(0, 150, 136));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());
                if(username.equals("admin") && password.equals("1234")) {
                    JOptionPane.showMessageDialog(panel, "Welcome to Trackino Store!");
                    cardLayout.show(mainPanel, "StoreMain");
                } else {
                    JOptionPane.showMessageDialog(panel, "Invalid Credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return panel;
    }

    // الشاشة الرئيسية للمتجر بعد تسجيل الدخول (تشمل الـ Sidebar والمحتوى المتغير)
    private JPanel createStoreMainPage() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // 1. القائمة الجانبية (Sidebar)
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(18, 30, 49));
        sidebar.setPreferredSize(new Dimension(220, 800));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel sideTitle = new JLabel("Trackino Menu");
        sideTitle.setFont(new Font("Arial", Font.BOLD, 20));
        sideTitle.setForeground(Color.WHITE);
        sideTitle.setBorder(BorderFactory.createEmptyBorder(20, 20, 30, 20));
        sidebar.add(sideTitle);

        storeCardLayout = new CardLayout();
        storeContentPanel = new JPanel(storeCardLayout);

        // إنشاء الصفحات الداخلية للـ Sidebar
        JPanel storePage = createStorePage();
        JPanel productsPage = createProductsPage();
        JPanel dashboardPage = createDashboardPage();

        storeContentPanel.add(storePage, "View_Store");
        storeContentPanel.add(productsPage, "View_Products");
        storeContentPanel.add(dashboardPage, "View_Dashboard");

        // مصفوفة الأزرار وتفعيلها للتنقل الحقيقي
        String[] menuItems = {"🛒 Store", "📦 Products", "📊 Dashboard", "🚪 Logout"};
        for (String item : menuItems) {
            JButton menuButton = new JButton(item);
            menuButton.setMaximumSize(new Dimension(200, 40));
            menuButton.setBackground(new Color(28, 43, 65));
            menuButton.setForeground(Color.WHITE);
            menuButton.setFocusPainted(false);
            menuButton.setBorderPainted(false);
            
            // لوجيك ربط أزرار القائمة بالصفحات
            menuButton.addActionListener(e -> {
                if (item.contains("Store")) storeCardLayout.show(storeContentPanel, "View_Store");
                else if (item.contains("Products")) storeCardLayout.show(storeContentPanel, "View_Products");
                else if (item.contains("Dashboard")) storeCardLayout.show(storeContentPanel, "View_Dashboard");
                else if (item.contains("Logout")) {
                    cartCount = 0; // تصفير السلة عند الخروج
                    cartLabel.setText("🛒 Cart: 0 items");
                    cardLayout.show(this.mainPanel, "Login");
                }
            });
            
            sidebar.add(menuButton);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        // 2. البار العلوي المشترك (Top Bar) فيه عداد السلة
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setPreferredSize(new Dimension(980, 60));
        topBar.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel pageTitle = new JLabel("Trackino Management System");
        pageTitle.setFont(new Font("Arial", Font.BOLD, 18));
        topBar.add(pageTitle, BorderLayout.WEST);

        cartLabel = new JLabel("🛒 Cart: 0 items");
        cartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        cartLabel.setForeground(new Color(0, 150, 136));
        topBar.add(cartLabel, BorderLayout.EAST);

        // تجميع العناصر باللوحة الرئيسية
        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.add(topBar, BorderLayout.NORTH);
        centerContainer.add(storeContentPanel, BorderLayout.CENTER);

        mainPanel.add(sidebar, BorderLayout.WEST);
        mainPanel.add(centerContainer, BorderLayout.CENTER);

        return mainPanel;
    }

    // أ) صفحة المتجر الـ 8 قطع الأساسية
    private JPanel createStorePage() {
        JPanel productsGrid = new JPanel(new GridLayout(2, 4, 20, 20));
        productsGrid.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        productsGrid.setBackground(new Color(245, 247, 250));

        String[] products = {
            "Arduino Uno R3", "Soil Moisture Sensor", "Water Pump 5V", "Relay Module",
            "LCD Display 16x2", "Jumper Wires Pack", "Breadboard", "Power Adapter 12V"
        };

        for (String prodName : products) {
            JPanel card = new JPanel(new BorderLayout());
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 230), 1));

            JLabel nameLabel = new JLabel(prodName, SwingConstants.CENTER);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
            card.add(nameLabel, BorderLayout.CENTER);

            JButton buyButton = new JButton("Add to Cart");
            buyButton.setBackground(new Color(0, 150, 136));
            buyButton.setForeground(Color.WHITE);
            buyButton.setFocusPainted(false);
            
            buyButton.addActionListener(e -> {
                cartCount++;
                cartLabel.setText("🛒 Cart: " + cartCount + " items");
                JOptionPane.showMessageDialog(this, prodName + " added to your cart!");
            });
            
            card.add(buyButton, BorderLayout.SOUTH);
            productsGrid.add(card);
        }

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.add(new JLabel("  🛒 Store / Browse Items", SwingConstants.LEFT), BorderLayout.NORTH);
        wrapper.add(new JScrollPane(productsGrid), BorderLayout.CENTER);
        return wrapper;
    }

    // ب) صفحة الـ Products (إضافة وعرض المنتجات بشكل منظم)
    private JPanel createProductsPage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("📦 Products Management Table (Static View)");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(title, BorderLayout.NORTH);

        // جدول صوري يعرض المنتجات الحالية في النظام
        String[] columnNames = {"Product ID", "Product Name", "Stock Status", "Price"};
        Object[][] data = {
            {"#1001", "Arduino Uno R3", "In Stock (15)", "$12.00"},
            {"#1002", "Soil Moisture Sensor", "In Stock (45)", "$3.50"},
            {"#1003", "Water Pump 5V", "Low Stock (3)", "$5.00"},
            {"#1004", "Relay Module", "In Stock (22)", "$2.00"}
        };

        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // زر تفاعلي لإضافة منتج جديد يطبع مسج صوري
        JButton addProdBtn = new JButton("+ Add New Product to System");
        addProdBtn.setBackground(new Color(18, 30, 49));
        addProdBtn.setForeground(Color.WHITE);
        addProdBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "Feature unlocked! New item form will connect to SQL in Phase 4."));
        panel.add(addProdBtn, BorderLayout.SOUTH);

        return panel;
    }

    // ج) صفحة الـ Dashboard (لوحة الإحصائيات الفخمة)
    private JPanel createDashboardPage() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 20, 20));
        panel.setBackground(new Color(245, 247, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));

        // كرت المبيعات
        JPanel card1 = new JPanel(new GridBagLayout());
        card1.setBackground(Color.WHITE);
        card1.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 136), 2));
        JLabel lbl1 = new JLabel("💰 Total Sales: $345.50");
        lbl1.setFont(new Font("Arial", Font.BOLD, 16));
        card1.add(lbl1);

        // كرت عدد المنتجات
        JPanel card2 = new JPanel(new GridBagLayout());
        card2.setBackground(Color.WHITE);
        card2.setBorder(BorderFactory.createLineBorder(new Color(18, 30, 49), 2));
        JLabel lbl2 = new JLabel("📦 Items Count: 8 Active Components");
        lbl2.setFont(new Font("Arial", Font.BOLD, 16));
        card2.add(lbl2);

        // كرت حالة السيستم للآردوينو
        JPanel card3 = new JPanel(new GridBagLayout());
        card3.setBackground(Color.WHITE);
        card3.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2));
        JLabel lbl3 = new JLabel("⚙️ System Status: Operational");
        lbl3.setFont(new Font("Arial", Font.BOLD, 16));
        card3.add(lbl3);

        panel.add(card1);
        panel.add(card2);
        panel.add(card3);

        JPanel mainDash = new JPanel(new BorderLayout());
        mainDash.add(new JLabel("  📊 Trackino Analytics Dashboard", SwingConstants.LEFT), BorderLayout.NORTH);
        mainDash.add(panel, BorderLayout.CENTER);

        return mainDash;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TrackinoStoreSystem().setVisible(true);
        });
    }
}